import sys
import os
import numpy as np
import cv2
import common
from common import CocoPart
import string
import random
import platform
import argparse
from libs.ustr import ustr

from xml.etree import ElementTree
from xml.etree.ElementTree import Element, SubElement
from lxml import etree
import codecs

sys.path.append('/usr/local/python')
    # Import Openpose (Windows/Ubuntu/OSX)
dir_path = os.path.dirname(os.path.realpath(__file__))
try:
        # Windows Import
        if platform == "win32":
            # Change these variables to point to the correct folder (Release/x64 etc.)
            sys.path.append(dir_path + '/../../python/openpose/Release');
            os.environ['PATH']  = os.environ['PATH'] + ';' + dir_path + '/../../x64/Release;' +  dir_path + '/../../bin;'
            import pyopenpose as op
        else:
            # Change these variables to point to the correct folder (Release/x64 etc.)
            sys.path.append('../../python');
            # If you run `make install` (default path is `/usr/local/python` for Ubuntu), you can also access the OpenPose/python module from there. This will install OpenPose and the python library at your desired installation path. Ensure that this is in your python path in order to use it.
            # sys.path.append('/usr/local/python')
            from openpose import pyopenpose as op
except ImportError as e:
        print('Error: OpenPose library could not be found. Did you enable `BUILD_PYTHON` in CMake and have this Python script in the right folder?')
        raise e


params = dict()
params["logging_level"] = 3
params["output_resolution"] = "-1x-1"
params["net_resolution"] = "-1x368"
params["model_pose"] = "COCO"
params["alpha_pose"] = 0.6
params["scale_gap"] = 0.3
params["scale_number"] = 1
params["render_threshold"] = 0.05
# If GPU version is built, and multiple GPUs are available, set the ID here
params["num_gpu_start"] = 0
params["disable_blending"] = True
# Ensure you point to the correct path where models are located
params["model_folder"] = "/home/fmiled/Bureau/openpose/models/"
# Construct OpenPose object allocates GPU memory
opWrapper = op.WrapperPython()
opWrapper.configure(params)
opWrapper.start()

IMAGE_EXTENTIONS = ['.bmp', '.cur', '.gif', '.icns', '.ico', '.jpeg', '.jpg', '.pbm', '.pgm', '.png', '.ppm', '.svg', '.svgz', '.tga', '.tif', '.tiff', '.wbmp', '.webp', '.xbm', '.xpm']
XML_EXT = '.xml'
TXT_EXT = '.txt'
ENCODE_METHOD = 'utf-8'

def scanAllImages(folderPath):
    l=os.listdir(folderPath)
    for i in range(len(l)):
    	l[i]=folderPath+"/"+l[i]
    return l

def getKeypointsOfImage(imagePath):
    datum = op.Datum()
    imageToProcess = cv2.imread(imagePath)
    datum.cvInputData = imageToProcess
    opWrapper.emplaceAndPop(op.VectorDatum([datum]))
    # Remove accuracy colunm and return
    return datum.poseKeypoints

def prettify(elem):
    """
        Return a pretty-printed XML string for the Element.
    """
    rough_string = ElementTree.tostring(elem, 'utf8')
    root = etree.fromstring(rough_string)
    return etree.tostring(root, pretty_print=True, encoding=ENCODE_METHOD).replace("  ".encode(), "\t".encode())
    # minidom does not support UTF-8
    '''reparsed = minidom.parseString(rough_string)
    return reparsed.toprettyxml(indent="\t", encoding=ENCODE_METHOD)'''

def saveKeypointsToXML(targetFile, keypoints):
    if not targetFile.endswith('xml'):
        return None
    
    top = Element('annotation')
    
    bndboxes = []
    
    for key in keypoints:
        XY = []
        X = []
        Y = []
        
        for p in key:
            x, y = int(p[0]), int(p[1])
            XY.append(x)
            XY.append(y)
            if x > 0:
                X.append(x)
            if y > 0:
                Y.append(y)
        
        xmin = min(X)
        xmax = max(X)
        ymin = min(Y)
        ymax = max(Y)
        
        each_object = {'xmin': xmin, 'xmax': xmax, 'ymin': ymin, 'ymax':ymax, 'keypoints': ', '.join(map(str, XY))}
        bndboxes.append(each_object)
    
    for each_object in bndboxes:
        object_item = SubElement(top, 'object')
        
        keypoints_item = SubElement(object_item, 'keypoints')
        keypoints_item.text = each_object['keypoints']
        
        bndbox = SubElement(object_item, 'bndbox')
        xmin = SubElement(bndbox, 'xmin')
        xmin.text = str(each_object['xmin'])
        ymin = SubElement(bndbox, 'ymin')
        ymin.text = str(each_object['ymin'])
        xmax = SubElement(bndbox, 'xmax')
        xmax.text = str(each_object['xmax'])
        ymax = SubElement(bndbox, 'ymax')
        ymax.text = str(each_object['ymax'])
    
    out_file = None
    if targetFile is None:
        out_file = codecs.open(
            self.filename + XML_EXT, 'w', encoding=ENCODE_METHOD)
    else:
        out_file = codecs.open(targetFile, 'w', encoding=ENCODE_METHOD)

    prettifyResult = prettify(top)
    out_file.write(prettifyResult.decode('utf8'))
    out_file.close()    

def saveKeypointsOfImage(imagePath, keypoints, outputType):
    dirPathContaint = os.path.split(os.path.dirname(imagePath))[0]
    
    nameWithoutExt = os.path.basename(os.path.splitext(imagePath)[0])
    
    dirPathSavedKeypoints = os.path.join(dirPathContaint, "keypoints")
    if not os.path.isdir(dirPathSavedKeypoints):
        os.mkdir(dirPathSavedKeypoints)
        
    if outputType == 'xml':
        keypointsFileName = os.path.join(dirPathSavedKeypoints, nameWithoutExt) + XML_EXT
        saveKeypointsToXML(keypointsFileName, keypoints)
    else:
        keypointsFileName = os.path.join(dirPathSavedKeypoints, nameWithoutExt) + TXT_EXT

        allKeypointsString = ""
        for key in keypoints:
            keypointsString = ""
            for pointTutle in key:
                keypointsString += "{}, {}, ".format(pointTutle[0], pointTutle[1])
            allKeypointsString += keypointsString[:-2] + "\n"
        
        with open(keypointsFileName, 'w') as f:
            f.write(allKeypointsString)           
                
    print(keypointsFileName)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Extract keypoints from an image and save it to a text file with same name')
    parser.add_argument('--imagedir', type=str, default='/home/ai/cuda-workspace/openpose/examples/media')
    parser.add_argument('--outputtype', type=str, default='txt')
    args = parser.parse_args()
    
    outputType = args.outputtype
    
    imagedir = args.imagedir
    print(imagedir)
    if imagedir != '' :
        images = scanAllImages(args.imagedir)
        for image in images:
            keypoints = getKeypointsOfImage(image)
            saveKeypointsOfImage(image, keypoints, outputType)
