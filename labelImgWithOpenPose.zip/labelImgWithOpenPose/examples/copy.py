import shutil,os
l=os.listdir("./images")

# specify the input file path
input_file = "./keypoints/crop-ex.txt"

# specify the output file path and name
l1=os.listdir("./keypoints")
with open(input_file, 'r') as input_file:
    input_content = input_file.read()

# open the output file and write the input content to it
for image in l:
    image=image[:len(image)-4]
    output_file = "./keypoints/"+image+".txt"
    if l1.count(output_file)==0:
        with open(output_file, 'w') as output_file:
            output_file.write(input_content)